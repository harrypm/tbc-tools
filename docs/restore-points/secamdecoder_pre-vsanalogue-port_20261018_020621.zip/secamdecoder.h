/************************************************************************

    secamdecoder.h

    tbc-chroma-decoder - Colourisation filter for the tbc format.

    Copyright (C) 2026 Harry Munday

    This file is part of tbc-tools.

    tbc-chroma-decoder is free software: you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

************************************************************************/

#ifndef SECAMDECODER_H
#define SECAMDECODER_H

#include <QObject>
#include <QAtomicInt>
#include <QThread>
#include <QDebug>

#include <complex>
#include <vector>

#include "componentframe.h"
#include "tbcmetadata.h"
#include "sourcevideo.h"

#include "decoder.h"
#include "sourcefield.h"

class DecoderPool;

// Decoder for SECAM sources whose chroma TBC carries a restored studio SECAM
// FM chroma block, as produced by vhs-decode's --system SECAM (method 1, the
// standard divide-by-4 recording used in France) and --system MESECAM paths.
// Both restore the block to the same studio rest carriers, foB = 4.25 MHz and
// foR = 4.40625 MHz.
//
// This decoder therefore does the FM demodulation itself: it quadrature
// demodulates each line, reads the D'R/D'B line identity and the discriminator
// zero from the blanking-interval rest carrier vhs-decode regenerates, undoes
// the SECAM LF pre-emphasis, and reconstructs simultaneous D'R/D'B by one-line
// hold. The result is written into ComponentFrame's U/V pre-scaled by
// OutputWriter's existing RGB48/YUV444P16 matrix constants, so the standard
// Y'UV->R'G'B' conversion reproduces SECAM's own inverse matrix without any
// change to OutputWriter.
class SecamDecoder : public Decoder {
public:

    struct SecamConfiguration {
        double chromaGain = 1.0;
        double chromaPhase = 0.0;  // hue rotation of (D'B, D'R) in degrees
        // FM click ("SECAM fire") concealment level. 0 bypasses the stage;
        // 1.0 is the default. Higher = more aggressive detection.
        double clickNrLevel = 1.0;
        // Original first active field line before any full-frame widening.
        // Rows below this are V-interval (bottles/test lines) and must
        // render neutral in full-frame mode even though they carry carrier;
        // -1 means use videoParameters.firstActiveFieldLine as-is.
        qint32 nominalFirstActiveFieldLine = -1;
        TbcMetaData::VideoParameters videoParameters;
    };

    SecamDecoder();
    SecamDecoder(const SecamDecoder::SecamConfiguration &config);
    bool updateConfiguration(const TbcMetaData::VideoParameters &videoParameters,
                             const SecamDecoder::SecamConfiguration &configuration);
    bool configure(const TbcMetaData::VideoParameters &videoParameters) override;
    QThread *makeThread(QAtomicInt& abort, DecoderPool& decoderPool) override;

    /// Synchronously decode SECAM chroma fields into component frames
    void decodeFrames(const QVector<SourceField>& inputFields,
                    qint32 startIndex,
                    qint32 endIndex,
                    QVector<ComponentFrame>& componentFrames);

private:
    // Per-call working buffers for one field's demodulation.
    struct FieldWork {
        std::vector<double> frequency;   // instantaneous frequency, Hz
        std::vector<double> envelope;    // carrier envelope
        std::vector<double> dr;          // (R'-Y'), filled to every line
        std::vector<double> db;          // (B'-Y'), filled to every line
        std::vector<double> demod;       // raw per-sample freq deviation (Hz), pre-concealment
        std::vector<bool> lineIsRed;
        std::vector<double> scratch;
        // TEMP diagnostic (SECAM flicker investigation)
        std::vector<double> restCarrier;
        qint32 parityEvenIsRed = 0;
        qint32 parityPicture = 0;
        bool parityDrOnEven = false;
        qint32 restRedCount = 0;
        double restMin = 0.0;
        double restMax = 0.0;
        double restMed = 0.0;
        double redRestMed = 0.0;   // median rest carrier over D'R-voted picture lines
        double blueRestMed = 0.0;  // median rest carrier over D'B-voted picture lines

        void resize(qint32 fieldHeight, qint32 fieldWidth);
    };

    /// Quadrature demodulate one field into work.frequency/work.envelope
    void demodulateField(const SourceVideo::Data &data, FieldWork &work) const;

    /// Demodulate a field and reconstruct simultaneous D'R/D'B in work.dr/work.db
    void decodeField(const SourceVideo::Data &data, FieldWork &work) const;

    /// Windowed-sinc lowpass used by the quadrature demodulator
    std::vector<double> demodTaps;

    // Rest-carrier measurement window inside the regenerated blanking interval
    qint32 restStart = 0;
    qint32 restEnd = 0;

    SecamConfiguration secamConfig;
};

class SecamThread : public DecoderThread
{
    Q_OBJECT
public:
    explicit SecamThread(QAtomicInt &abort, DecoderPool &decoderPool,
                       const SecamDecoder::SecamConfiguration &secamConfig,
                       QObject *parent = nullptr);

protected:
    void decodeFrames(const QVector<SourceField> &inputFields, qint32 startIndex, qint32 endIndex,
                      QVector<ComponentFrame> &componentFrames) override;

private:
    // Settings
    const SecamDecoder::SecamConfiguration &secamConfig;
};

#endif // SECAMDECODER_H
