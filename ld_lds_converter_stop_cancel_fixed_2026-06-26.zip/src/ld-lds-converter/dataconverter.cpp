/************************************************************************

    dataconverter.cpp

    ld-lds-converter - 10-bit to 16-bit .lds converter for ld-decode
    Copyright (C) 2019 Simon Inns

    This file is part of ld-decode-tools.

    ld-lds-converter is free software: you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

************************************************************************/

#include "dataconverter.h"
#include "tbc/logging.h"
#include <FLAC/stream_encoder.h>

#include <QByteArray>
#include <QDir>
#include <QFileInfo>
#include <QVector>
#include <QVersionNumber>

#include <algorithm>
#include <cstdio>

DataConverter::DataConverter(QString inputFileNameParam,
                             QString outputFileNameParam,
                             bool isPackingParam,
                             OutputFormat outputFormatParam,
                             int flacSampleRateParam,
                             int flacCompressionLevelParam,
                             QObject *parent)
    : QObject(parent),
      inputFileName(inputFileNameParam),
      outputFileName(outputFileNameParam),
      isPacking(isPackingParam),
      outputFormat(outputFormatParam),
      flacSampleRate(std::max(1, flacSampleRateParam)),
      flacCompressionLevel(std::clamp(flacCompressionLevelParam, 0, 8)),
      inputFileHandle(nullptr),
      outputFileHandle(nullptr),
      flacEncoder(nullptr),
      totalInputBytes(0),
      processedInputBytes(0),
      cancelRequested(false),
      conversionCancelled(false)
{
}

void DataConverter::requestCancel()
{
    cancelRequested = true;
}

bool DataConverter::wasCancelled() const
{
    return conversionCancelled;
}

QString DataConverter::outputExtensionForFormat(OutputFormat outputFormatParam)
{
    switch (outputFormatParam) {
    case OutputFormat::Flac:
        return QStringLiteral(".flac");
    case OutputFormat::S16Raw:
        return QStringLiteral(".s16");
    case OutputFormat::RiffWave:
        return QStringLiteral(".wav");
    }

    return QStringLiteral(".bin");
}

QString DataConverter::defaultOutputPath(const QString &inputFileNameParam,
                                         bool isPackingParam,
                                         OutputFormat outputFormatParam)
{
    const QFileInfo inputInfo(inputFileNameParam);
    if (inputFileNameParam.trimmed().isEmpty()) {
        return QString();
    }

    QString baseName = inputInfo.completeBaseName();
    if (baseName.isEmpty()) {
        baseName = inputInfo.fileName();
    }
    if (baseName.isEmpty()) {
        return QString();
    }

    const QString extension = isPackingParam ? QStringLiteral(".lds") : outputExtensionForFormat(outputFormatParam);
    const QString directoryPath = inputInfo.path().isEmpty() ? QStringLiteral(".") : inputInfo.path();
    return QDir(directoryPath).filePath(baseName + extension);
}

// Method to process the conversion of the file
bool DataConverter::process(void)
{
    conversionCancelled = false;
    // Open the input file
    if (!openInputFile()) {
        qCritical("Could not open input file!");
        return false;
    }
    emit progressUpdated(processedInputBytes, totalInputBytes);

    // Open the output file
    if (!openOutputFile()) {
        qCritical("Could not open output file!");
        closeInputFile();
        return false;
    }

    // Packing or unpacking?
    const bool conversionSucceeded = isPacking ? packFile() : unpackFile();

    if (conversionSucceeded && totalInputBytes > 0) {
        processedInputBytes = totalInputBytes;
        emit progressUpdated(processedInputBytes, totalInputBytes);
    }

    // Close the input file
    closeInputFile();

    // Close the output file
    closeOutputFile();

    // Exit with result
    return conversionSucceeded;
}

// Method to open the input file for reading
bool DataConverter::openInputFile(void)
{
    totalInputBytes = 0;
    processedInputBytes = 0;
    // Do we have a file name for the input file?
    if (inputFileName.isEmpty()) {
        // No source input file name was specified, using stdin instead
        tbcDebugStream() << "No input filename was provided, using stdin";
        inputFileHandle = new QFile;
        if (!inputFileHandle->open(stdin, QIODevice::ReadOnly)) {
            // Failed to open stdin
            qWarning() << "Could not open stdin as input file";
            return false;
        }
        tbcDebugStream() << "Reading input data from stdin";
    } else {
        // Open input file for reading
        inputFileHandle = new QFile(inputFileName);
        if (!inputFileHandle->open(QIODevice::ReadOnly)) {
            // Failed to open source sample file
            tbcDebugStream() << "Could not open" << inputFileName << "as input file";
            return false;
        }
        totalInputBytes = std::max<qint64>(0, inputFileHandle->size());
        tbcDebugStream() << "DataConverter::openInputFile(): Input file is" << inputFileName << "and is" << inputFileHandle->size() << "bytes in length";
    }

    // Exit with success
    return true;
}

// Method to close the input file
void DataConverter::closeInputFile(void)
{
    // Is an input file open?
    if (inputFileHandle != nullptr) {
        inputFileHandle->close();
    }

    // Clear the file handle pointer
    delete inputFileHandle;
    inputFileHandle = nullptr;
}

// Method to open the output file for writing
bool DataConverter::openOutputFile(void)
{
    if (!isPacking && outputFormat == OutputFormat::Flac) {
        return openFlacEncoder();
    }

    // Do we have a file name for the output file?
    if (outputFileName.isEmpty()) {
        // No output file name was specified, using stdout instead
        tbcDebugStream() << "No output filename was provided, using stdout";
        outputFileHandle = new QFile;
        if (!outputFileHandle->open(stdout, QIODevice::WriteOnly)) {
            // Failed to open stdout
            qWarning() << "Could not open stdout as output file";
            return false;
        }
        tbcDebugStream() << "Writing output data to stdout";

    } else {
        // Open the output file for writing
        outputFileHandle = new QFile(outputFileName);

        if (!outputFileHandle->open(QIODevice::WriteOnly)) {
            // Failed to open output file
            tbcDebugStream() << "DataConverter::openOutputFile(): Could not open" << outputFileName << "as output file";
            return false;
        }
        tbcDebugStream() << "DataConverter::openOutputFile(): Output file is" << outputFileName;
    }

    // Exit with success
    return true;
}

bool DataConverter::openFlacEncoder(void)
{
    const QString flacVersionString = QString::fromLatin1(FLAC__VERSION_STRING);
    const QVersionNumber detectedFlacVersion = QVersionNumber::fromString(flacVersionString);
    const QVersionNumber minimumSupportedFlacVersion(1, 5, 0);
    if (!detectedFlacVersion.isNull() &&
        QVersionNumber::compare(detectedFlacVersion, minimumSupportedFlacVersion) < 0) {
        qCritical("libFLAC %s is too old; version 1.5.0 or newer is required", FLAC__VERSION_STRING);
        return false;
    }
    flacEncoder = FLAC__stream_encoder_new();
    if (flacEncoder == nullptr) {
        qCritical("Could not create FLAC encoder instance");
        return false;
    }

    FLAC__stream_encoder_set_channels(flacEncoder, 1);
    FLAC__stream_encoder_set_bits_per_sample(flacEncoder, 16);
    FLAC__stream_encoder_set_sample_rate(flacEncoder, static_cast<unsigned>(flacSampleRate));
    FLAC__stream_encoder_set_compression_level(flacEncoder, static_cast<unsigned>(flacCompressionLevel));
    FLAC__stream_encoder_set_streamable_subset(flacEncoder, true);
    FLAC__stream_encoder_set_verify(flacEncoder, true);

    FLAC__StreamEncoderInitStatus initStatus;
    if (outputFileName.isEmpty()) {
        tbcDebugStream() << "No output filename was provided, writing FLAC output to stdout";
        initStatus = FLAC__stream_encoder_init_FILE(flacEncoder, stdout, nullptr, nullptr);
    } else {
        const QByteArray encodedFileName = QFile::encodeName(outputFileName);
        initStatus = FLAC__stream_encoder_init_file(flacEncoder, encodedFileName.constData(), nullptr, nullptr);
    }

    if (initStatus != FLAC__STREAM_ENCODER_INIT_STATUS_OK) {
        qCritical("Could not initialise FLAC encoder: %s", FLAC__StreamEncoderInitStatusString[initStatus]);
        FLAC__stream_encoder_delete(flacEncoder);
        flacEncoder = nullptr;
        return false;
    }

    return true;
}

// Method to close the output file
void DataConverter::closeOutputFile(void)
{
    if (flacEncoder != nullptr) {
        if (!FLAC__stream_encoder_finish(flacEncoder)) {
            qWarning("Finalizing FLAC encoder failed");
        }
        FLAC__stream_encoder_delete(flacEncoder);
        flacEncoder = nullptr;
    }

    // Is an output file open?
    if (outputFileHandle != nullptr) {
        outputFileHandle->close();
    }

    // Clear the file handle pointer
    delete outputFileHandle;
    outputFileHandle = nullptr;
}

bool DataConverter::writeRiffHeader(void)
{
    if (outputFileHandle == nullptr) {
        qCritical("No output file handle available for RIFF output");
        return false;
    }

    // Writes a WAV RIFF header, 40k, mono, 16-bit signed
    const QString riffHex = QStringLiteral("52494646FFFFFFFF57415645666D74201000000001000100409C000088580100020010004C4953541A000000494E464F495346540E0000004C61766635382E32392E3130300064617461FFFFFFFF");
    const QByteArray riffArray = QByteArray::fromHex(riffHex.toLatin1());
    const qint64 bytesWritten = outputFileHandle->write(riffArray);
    if (bytesWritten != riffArray.size()) {
        qCritical("Could not write RIFF header to output file");
        return false;
    }
    return true;
}

bool DataConverter::writeUnpackedSamples(const qint16 *samples, qint32 sampleCount)
{
    if (sampleCount <= 0 || samples == nullptr) {
        return true;
    }

    if (!isPacking && outputFormat == OutputFormat::Flac) {
        if (flacEncoder == nullptr) {
            qCritical("FLAC encoder is not initialised");
            return false;
        }

        QVector<FLAC__int32> flacBuffer(sampleCount);
        for (qint32 samplePointer = 0; samplePointer < sampleCount; samplePointer++) {
            flacBuffer[samplePointer] = samples[samplePointer];
        }

        if (!FLAC__stream_encoder_process_interleaved(flacEncoder,
                                                      flacBuffer.constData(),
                                                      static_cast<unsigned>(sampleCount))) {
            const FLAC__StreamEncoderState flacState = FLAC__stream_encoder_get_state(flacEncoder);
            qCritical("Could not write FLAC output: %s", FLAC__StreamEncoderStateString[flacState]);
            return false;
        }
        return true;
    }

    if (outputFileHandle == nullptr) {
        qCritical("Output file handle is not initialised");
        return false;
    }

    const qint64 outputBytes = static_cast<qint64>(sampleCount) * static_cast<qint64>(sizeof(qint16));
    const qint64 bytesWritten = outputFileHandle->write(reinterpret_cast<const char *>(samples), outputBytes);
    if (bytesWritten != outputBytes) {
        qCritical("Could not write to output file");
        return false;
    }

    return true;
}

// Method to pack 16-bit data into 10-bit data
bool DataConverter::packFile(void)
{
    tbcDebugStream() << "DataConverter::packFile(): Packing";
    QByteArray inputBuffer;
    QByteArray outputBuffer;
    bool isComplete = false;

    while(!isComplete) {
        if (cancelRequested) {
            conversionCancelled = true;
            qWarning("Conversion cancelled by user");
            return false;
        }
        // Input buffer must be divisible by 8 bytes due to output packing
        const qint32 bufferSizeInBytes = (20 * 1024 * 1024); // = 20MiBytes
        inputBuffer.resize(bufferSizeInBytes);

        // Every 4 input words (8 bytes) is 5 output bytes
        outputBuffer.resize((bufferSizeInBytes / 8) * 5);

        // Fill the input buffer with data
        qint64 receivedBytes = 0;
        qint32 totalReceivedBytes = 0;
        do {
            receivedBytes = inputFileHandle->read(reinterpret_cast<char *>(inputBuffer.data() + totalReceivedBytes),
                                                  inputBuffer.size() - totalReceivedBytes);
            if (receivedBytes > 0) totalReceivedBytes += static_cast<qint32>(receivedBytes);
        } while (receivedBytes > 0 && totalReceivedBytes < bufferSizeInBytes);

        // Check for end of file
        if (receivedBytes == 0) isComplete = true;

        if (totalReceivedBytes != 0) {
            const qint32 usableBytes = (totalReceivedBytes / 8) * 8;
            if (usableBytes != totalReceivedBytes) {
                qWarning() << "Input byte count is not aligned to 16-bit sample groups; dropping trailing"
                           << (totalReceivedBytes - usableBytes) << "bytes";
            }
            if (usableBytes == 0) {
                continue;
            }

            inputBuffer.resize(usableBytes);
            outputBuffer.resize((usableBytes / 8) * 5);
            tbcDebugStream() << "DataConverter::packFile(): Got" << usableBytes << "aligned bytes from input file";

            qint32 word0, word1, word2, word3;
            qint32 outputBufferPointer = 0;

            qint16 *input = reinterpret_cast<qint16 *>(inputBuffer.data());

            for (qint32 wordPointer = 0; wordPointer < (usableBytes / 2); wordPointer += 4) {
                if ((wordPointer & 0x3FFF) == 0 && cancelRequested) {
                    conversionCancelled = true;
                    qWarning("Conversion cancelled by user");
                    return false;
                }
                word0 = (input[wordPointer + 0] / 64) + 512;
                word1 = (input[wordPointer + 1] / 64) + 512;
                word2 = (input[wordPointer + 2] / 64) + 512;
                word3 = (input[wordPointer + 3] / 64) + 512;

                outputBuffer[outputBufferPointer + 0]  = static_cast<char>((word0 & 0x03FC) >> 2);
                outputBuffer[outputBufferPointer + 1]  = static_cast<char>(((word0 & 0x0003) << 6) + ((word1 & 0x03F0) >> 4));
                outputBuffer[outputBufferPointer + 2]  = static_cast<char>(((word1 & 0x000F) << 4) + ((word2 & 0x03C0) >> 6));
                outputBuffer[outputBufferPointer + 3]  = static_cast<char>(((word2 & 0x003F) << 2) + ((word3 & 0x0300) >> 8));
                outputBuffer[outputBufferPointer + 4]  = static_cast<char>(word3 & 0x00FF);

                // Increment the packed sample buffer pointer
                outputBufferPointer += 5;
            }

            // Write the output buffer to the output file
            const qint64 bytesWritten = outputFileHandle->write(reinterpret_cast<const char *>(outputBuffer.data()),
                                                                outputBuffer.size());
            if (bytesWritten != outputBuffer.size()) {
                qCritical("Could not write to output file!");
                return false;
            }
            tbcDebugStream() << "DataConverter::packFile(): Wrote" << outputBuffer.size() << "bytes to output file";

            processedInputBytes += totalReceivedBytes;
            if (totalInputBytes > 0) {
                processedInputBytes = std::min(processedInputBytes, totalInputBytes);
            }
            emit progressUpdated(processedInputBytes, totalInputBytes);
        } else {
            // Input file is empty
            tbcDebugStream() << "DataConverter::packFile(): Got zero bytes from input file";
            isComplete = true;
        }
    }

    return true;
}

// Method to unpack 10-bit data into 16-bit data
bool DataConverter::unpackFile(void)
{
    tbcDebugStream() << "DataConversion::unpackFile(): Unpacking";
    QByteArray inputBuffer;
    QByteArray outputBuffer;
    bool isComplete = false;

    if (outputFormat == OutputFormat::RiffWave && !writeRiffHeader()) {
        return false;
    }

    while(!isComplete) {
        if (cancelRequested) {
            conversionCancelled = true;
            qWarning("Conversion cancelled by user");
            return false;
        }
        // Input buffer must be divisible by 5 bytes due to 10-bit data format
        const qint32 bufferSizeInBytes = (5 * 1024 * 1024) * 4; // 5MiB * 4 = 20MiBytes
        inputBuffer.fill(0, bufferSizeInBytes);

        // Fill the input buffer with data
        qint64 receivedBytes = 0;
        qint32 totalReceivedBytes = 0;
        do {
            receivedBytes = inputFileHandle->read(reinterpret_cast<char *>(inputBuffer.data() + totalReceivedBytes),
                                                  bufferSizeInBytes - totalReceivedBytes);
            if (receivedBytes > 0) totalReceivedBytes += static_cast<qint32>(receivedBytes);
        } while (receivedBytes > 0 && totalReceivedBytes < bufferSizeInBytes);

        // Check for end of file
        if (receivedBytes == 0) isComplete = true;

        if (totalReceivedBytes != 0) {
            const qint32 completeInputBytes = (totalReceivedBytes / 5) * 5;
            if (completeInputBytes != totalReceivedBytes) {
                qWarning() << "Input byte count is not aligned to packed 10-bit groups; dropping trailing"
                           << (totalReceivedBytes - completeInputBytes) << "bytes";
            }
            if (completeInputBytes == 0) {
                continue;
            }

            // Every 5 input bytes is 4 output words (8 bytes)
            outputBuffer.resize((completeInputBytes / 5) * 8);
            tbcDebugStream() << "DataConverter::unpackFile(): Got" << completeInputBytes << "aligned bytes from input file";

            char byte0, byte1, byte2, byte3, byte4;
            qint32 word0, word1, word2, word3;
            qint32 outputBufferPointer = 0;

            qint16 *output = reinterpret_cast<qint16 *>(outputBuffer.data());

            for (qint32 bytePointer = 0; bytePointer < completeInputBytes; bytePointer += 5) {
                if ((bytePointer & 0x3FFF) == 0 && cancelRequested) {
                    conversionCancelled = true;
                    qWarning("Conversion cancelled by user");
                    return false;
                }
                // Unpack the 5 bytes into 4x 10-bit values

                // Unpacked:                 Packed:
                // 0: xxxx xx00 0000 0000    0: 0000 0000 0011 1111
                // 1: xxxx xx11 1111 1111    2: 1111 2222 2222 2233
                // 2: xxxx xx22 2222 2222    4: 3333 3333
                // 3: xxxx xx33 3333 3333

                byte0 = inputBuffer[bytePointer + 0];
                byte1 = inputBuffer[bytePointer + 1];
                byte2 = inputBuffer[bytePointer + 2];
                byte3 = inputBuffer[bytePointer + 3];
                byte4 = inputBuffer[bytePointer + 4];

                // Use multiplication instead of left-shift to avoid implicit conversion issues
                word0  = ((byte0 & 0xFF) *   4) + ((byte1 & 0xC0) >> 6);
                word1  = ((byte1 & 0x3F) *  16) + ((byte2 & 0xF0) >> 4);
                word2  = ((byte2 & 0x0F) *  64) + ((byte3 & 0xFC) >> 2);
                word3  = ((byte3 & 0x03) * 256) + ((byte4 & 0xFF)     );

                output[outputBufferPointer + 0] = static_cast<qint16>((word0 - 512) * 64);
                output[outputBufferPointer + 1] = static_cast<qint16>((word1 - 512) * 64);
                output[outputBufferPointer + 2] = static_cast<qint16>((word2 - 512) * 64);
                output[outputBufferPointer + 3] = static_cast<qint16>((word3 - 512) * 64);

                // Increment the sample buffer pointer
                outputBufferPointer += 4;
            }

            if (!writeUnpackedSamples(output, outputBufferPointer)) {
                return false;
            }

            tbcDebugStream() << "DataConverter::unpackFile(): Wrote" << outputBuffer.size() << "bytes of decoded s16 data";

            processedInputBytes += totalReceivedBytes;
            if (totalInputBytes > 0) {
                processedInputBytes = std::min(processedInputBytes, totalInputBytes);
            }
            emit progressUpdated(processedInputBytes, totalInputBytes);
        } else {
            // Input file is empty
            tbcDebugStream() << "DataConverter::unpackFile(): Got zero bytes from input file";
            isComplete = true;
        }
    }

    return true;
}
