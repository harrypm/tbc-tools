/* src/interfaces/ecpg/include/ecpg_config.h.  Generated from src/interfaces/ecpg/include/ecpg_config.h.in by src/tools/msvc/Solution.pm.  */
/* Define to 1 to build client libraries as thread-safe code.
 *    (--enable-thread-safety) */
#define ENABLE_THREAD_SAFETY 1

/* Define to 1 if the system has the type `int64'. */
/* #undef HAVE_INT64 */

/* Define to 1 if `long int' works and is 64 bits. */
/* #undef HAVE_LONG_INT_64 */

/* Define to 1 if the system has the type `long long int'. */
#define HAVE_LONG_LONG_INT 1

/* Define to 1 if `long long int' works and is 64 bits. */
#define HAVE_LONG_LONG_INT_64 1

/* Define to 1 to use <stdbool.h> to define type bool. */
#define PG_USE_STDBOOL 1
